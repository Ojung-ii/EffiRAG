import json
import re
from datetime import datetime
from pathlib import Path
from statistics import mean
from typing import Any, Dict, List

TOKEN_RE = re.compile(r"[A-Za-z0-9]+")

STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "by",
    "for",
    "from",
    "has",
    "he",
    "in",
    "is",
    "it",
    "its",
    "of",
    "on",
    "that",
    "the",
    "to",
    "was",
    "were",
    "will",
    "with",
    "who",
    "what",
    "when",
    "where",
    "which",
    "how",
}


def tokenize(text):
    return [t.lower() for t in TOKEN_RE.findall(text)]


def content_tokens(text):
    return [t for t in tokenize(text) if len(t) > 2 and t not in STOPWORDS]


def safe_div(num: float, den: float) -> float:
    if den == 0:
        return 0.0
    return num / den


def mean_or_zero(values):
    if not values:
        return 0.0
    return float(mean(values))


def ensure_parent(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)


def write_json(path, payload):
    ensure_parent(path)
    with Path(path).open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)


def write_jsonl(path, rows):
    ensure_parent(path)
    with Path(path).open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def append_jsonl(path, row):
    ensure_parent(path)
    with Path(path).open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def timestamp_for_filename():
    return datetime.utcnow().strftime("%Y%m%d_%H%M%S_%f")


def timestamp_iso_utc():
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def markdown_table(headers, rows):
    safe_headers = [str(h) for h in headers]
    lines = [
        "| " + " | ".join(safe_headers) + " |",
        "| " + " | ".join(["---"] * len(safe_headers)) + " |",
    ]
    for row in rows:
        safe_row = [str(cell) for cell in row]
        lines.append("| " + " | ".join(safe_row) + " |")
    return "\n".join(lines)


def infer_config_filename_hints(path):
    name = Path(path).name.lower()
    hints = {}
    if "entity_chunk_graph" in name:
        hints["graph_mode"] = "entity_chunk_graph"
    elif any(tok in name for tok in ["fusion", "semantic_bridge", "baseline_aggressive", "top1corr"]):
        hints["graph_mode"] = "current_entity_graph"

    if "mixed_diffusion" in name:
        hints["chunk_node_enabled_in_diffusion"] = True
    elif "entity_seed_chunk_lift" in name:
        hints["chunk_node_enabled_in_diffusion"] = False

    return hints


def validate_config_against_filename(path, payload):
    payload = dict(payload or {})
    hints = infer_config_filename_hints(path)
    warnings = []
    for key, expected in hints.items():
        if key not in payload:
            continue
        actual = payload.get(key)
        if actual != expected:
            warnings.append({
                "field": str(key),
                "expected_from_filename": expected,
                "actual_in_yaml": actual,
            })

    graph_mode = str(payload.get("graph_mode", "current_entity_graph") or "current_entity_graph")
    if graph_mode == "entity_chunk_graph":
        if int(payload.get("samples_per_anchor", 1) or 1) <= 1:
            warnings.append({
                "field": "samples_per_anchor",
                "expected_from_strategy": ">=2 for stable run selection",
                "actual_in_yaml": payload.get("samples_per_anchor", 1),
            })
        if int(payload.get("phase1_run_preshortlist_topm", 1) or 1) <= 1:
            warnings.append({
                "field": "phase1_run_preshortlist_topm",
                "expected_from_strategy": ">=2 for stable run selection",
                "actual_in_yaml": payload.get("phase1_run_preshortlist_topm", 1),
            })
        if int(payload.get("phase1_full_run_score_topk", 1) or 1) <= 1:
            warnings.append({
                "field": "phase1_full_run_score_topk",
                "expected_from_strategy": ">=2 for stable run selection",
                "actual_in_yaml": payload.get("phase1_full_run_score_topk", 1),
            })
    return warnings


def parse_bool(value):
    if isinstance(value, bool):
        return value
    value = value.strip().lower()
    if value in {"1", "true", "t", "yes", "y", "on"}:
        return True
    if value in {"0", "false", "f", "no", "n", "off"}:
        return False
    raise ValueError(f"Cannot parse boolean value: {value}")


def load_yaml(path):
    import yaml

    with Path(path).open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    if not isinstance(data, dict):
        raise ValueError(f"Expected mapping in yaml file: {path}")
    warnings = validate_config_against_filename(path, data)
    data["_config_file"] = str(path)
    data["_config_audit"] = {
        "warning_count": int(len(warnings)),
        "warnings": warnings,
    }
    return data
